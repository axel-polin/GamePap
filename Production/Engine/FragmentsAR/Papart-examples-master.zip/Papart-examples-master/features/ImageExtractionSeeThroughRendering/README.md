## Image Extraction with Augmented reality rendering

In this example we extract a portion of image of 50mm x 50mm to
a 64x64pixels image.

### Screenshot

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/Camera/ImageExtractionSeeThroughRendering/screenshot.png "Screenshot")
