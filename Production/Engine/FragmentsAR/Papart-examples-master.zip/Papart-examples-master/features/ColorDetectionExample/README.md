## Color Capture with Augmented reality rendering

In this example we extract a portion of image of 10mm x 10mm (default size).
The average color is computed and displayed in a small square.


### Screenshot

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/Camera/ColorDetectionExample/screenshot.png "Screenshot")
