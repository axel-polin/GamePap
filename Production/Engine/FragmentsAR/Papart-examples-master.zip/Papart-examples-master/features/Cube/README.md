# Cube tracking, with 6 markers

Work in progress
