#### Utilities

- [ExtractPlanarObjectForTracking](ExtractPlanarObjectForTracking) : Utility to extract part of an image.
- [GuiCorners](GuiCorners): find the 3D location of a 2D object by setting its corners on the camera feed.
- [GuiCornersProj](https://github.com/poqudrof/Papart-examples/tree/master/papart-examples/Camera/GuiCorners): find the 3D location of a 2D object by setting its corners with the projection. 
