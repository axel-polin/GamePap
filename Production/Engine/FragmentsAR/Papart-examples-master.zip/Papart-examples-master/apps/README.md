### Advanced examples, mini applications.

- [Halloween](Halloween): take a depth shot, and spay it with blood projection.
- [Halloween2](Halloween2): write with bloody writing!
- [Human Printer](HumanPrinter): Display images at scale, with reloading the image and save/load the image location. 
- [Lapin](Lapin): require 3D red cyan glasses. 3D model of a rabbit.
- [Particles](Particles): particles are attracted to touch, objects. press 'g' to add/remove gravity!
- [Light](light): Learn about color with this app. You need to print the cards and cut them to try it !
