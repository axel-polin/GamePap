# Halloween

Drops of blood everywhere you touch.

![screenshot](https://github.com/potioc/Papart-examples/blob/master/apps/Halloween/halloween.png)

Example on a wall:

![screenshot](https://github.com/potioc/Papart-examples/blob/master/apps/Halloween/halloween_wall.jpg)
