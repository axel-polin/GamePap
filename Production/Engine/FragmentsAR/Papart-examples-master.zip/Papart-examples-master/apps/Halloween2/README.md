# Halloween 2

Watch out! Your arm is bleeding!

![screenshot](https://github.com/potioc/Papart-examples/blob/master/apps/Halloween2/halloween2.png)
