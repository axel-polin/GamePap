# Lapin

Displays a 3D model of a rabbit ; this application should be used with 3D red cyan glasses.

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/apps/Lapin/lapin.png)
