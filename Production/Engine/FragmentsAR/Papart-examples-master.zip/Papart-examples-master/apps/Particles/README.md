# Particles

Particules spread around objects that touch the table. Press 'g' to switch on/off gravity.

![Particles on screen](https://github.com/potioc/Papart-examples/blob/master/apps/Particles/particles2.png)
![Particles projected on a table](https://github.com/potioc/Papart-examples/blob/master/apps/Particles/particles_projection.jpg)
