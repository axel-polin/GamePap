## Debug mode - PapARt without hardware

In this example, we show that the PapARt library can work without any hardware. 
The PaperScreens are displayed like small windows inside the Processing window. 
