# Multitouch

Shows with blue circle the 2D touches (on a table for example) and with red circles the 3D touches (space).

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/Projection2D/MultiTouch/multitouch2D.jpg)

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/Projection2D/MultiTouch/multitouch3D.jpg)
