# Multitouch Details

Same as Multitouch, but with the details from the hands and objects that are captured. Touch is shown with blue circles.

![screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/Projection2D/MultiTouchDetails/multitouch_details.jpg)
