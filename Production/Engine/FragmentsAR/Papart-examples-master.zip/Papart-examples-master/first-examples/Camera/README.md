
# Camera

- [SeeThroughOnePaper](SeeThroughOnePaper): Simple PapARt application, on paper screen is used for 2D rendering inside it. 
- [SeeThroughWith3DObject](SeeThroughWith3DObject): This example shows the **two types** of rendering: **DrawAroundPaper** and **DrawOnPaper**.
- [SeeThroughGUI](SeeThroughGUI) : the user interface is in  screen space.
- [SeeThroughGUIInsidePaper](SeeThroughGUIInsidePaper): example of a user interface inside the PaperScreen. 
- Sample application : [SolarSystem](https://github.com/poqudrof/Papart-examples/tree/master/apps/SolarSystem), 3 paperScreens displaying a 3D model each.
