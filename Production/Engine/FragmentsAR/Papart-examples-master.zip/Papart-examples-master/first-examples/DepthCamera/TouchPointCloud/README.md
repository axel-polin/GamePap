#Application
This application shows how to use the height of objects.

Points are greyscaled, from black = lowest point on the plan to white = heighest points that can be captured.


#Results
Here we can see that the book is drawn in light grey, the roof of the house is white and the table is black.

What is on the table

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/DepthCamera/TouchPointCloud/20160707_110737.jpg)

With height processing

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/DepthCamera/TouchPointCloud/touchpoint.png)
