# Application
This application implements the Skatolo library and shows how to include buttons and controllers in your applications.

On the left there is a button that changes of color when pressed ; on the rigth there is a toggle button that remains toggled / untoggled when pressed.

# Screenshot

![Screenshot](https://github.com/potioc/Papart-examples/blob/master/papart-examples/DepthCamera/TouchWithGUI/screenshot.png)
